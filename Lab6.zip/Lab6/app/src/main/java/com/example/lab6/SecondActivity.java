package com.example.lab6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    MySharedPreference mySharedPreference2;
    TextView textView2;
    String nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView2 = findViewById(R.id.textView2);
        mySharedPreference2 = new MySharedPreference(this);
        String out= mySharedPreference2.getValue();
        textView2.setText(out);

        Intent i = getIntent();
        String outIntent = i.getStringExtra("name");
        Toast.makeText(this, outIntent, Toast.LENGTH_SHORT).show();

    }
}
